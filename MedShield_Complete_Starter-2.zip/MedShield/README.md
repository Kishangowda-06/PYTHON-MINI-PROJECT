# MedShield — Healthcare Security & Access Platform

A runnable full-stack starter for the MedShield concept: React + TypeScript + Vite frontend, FastAPI backend, SQLAlchemy, SQLite local database, JWT authentication, role-based access, appointments, medical records, emergency events, and audit events.

> **Important:** This is a development/demo foundation, not a certified clinical system or production-ready deployment. Use synthetic data only. Before real patient use, add professional security review, jurisdiction-specific legal review, managed secrets, PostgreSQL, private object storage, backups, monitoring, and validated notification integrations. AI analysis and external delivery integrations are not configured; the UI/API does not claim they are active.

## Requirements
- Python 3.11+
- Node.js 20+

## Quick start — Windows PowerShell

### 1. Start backend
```powershell
cd backend
py -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
Copy-Item .env.example .env
uvicorn app.main:app --reload --host 127.0.0.1 --port 8000
```
API docs: http://127.0.0.1:8000/docs

### 2. Start frontend in a second terminal
```powershell
cd frontend
npm install
Copy-Item .env.example .env
npm run dev
```
Open the URL Vite prints (normally http://localhost:5173).

### Demo use
Register a new account. Choose a role to explore the role-specific navigation. In a real deployment, public self-selection of privileged roles must be disabled; hospital and security administrators should be provisioned through a controlled onboarding process. The demo supports Patient, Doctor, Hospital Staff, Hospital Administrator, and Platform Security Administrator roles for local testing.

## Included API
- `POST /api/auth/register`, `POST /api/auth/login`, `GET /api/auth/me`
- `GET/POST /api/doctors`
- `GET/POST /api/appointments`, `PATCH /api/appointments/{id}`
- `GET/POST /api/records`
- `GET/POST /api/emergencies`, `PATCH /api/emergencies/{id}`
- `GET /api/audit`
- `GET /api/health`

The local SQLite database is created automatically at `backend/medshield.db`. Never commit `.env`, databases, uploaded medical files, or secrets.
