import os
from datetime import datetime, timedelta, timezone
from enum import Enum
from typing import Optional
from dotenv import load_dotenv
from fastapi import FastAPI, Depends, HTTPException, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import OAuth2PasswordBearer, OAuth2PasswordRequestForm
from jose import jwt, JWTError
from passlib.context import CryptContext
from pydantic import BaseModel, EmailStr, Field
from sqlalchemy import create_engine, String, Integer, DateTime, Text, ForeignKey
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, sessionmaker, Session

load_dotenv()
DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///./medshield.db")
JWT_SECRET = os.getenv("JWT_SECRET", "development-only-change-me")
ALGORITHM = "HS256"
TOKEN_MINUTES = int(os.getenv("ACCESS_TOKEN_MINUTES", "60"))
connect_args = {"check_same_thread": False} if DATABASE_URL.startswith("sqlite") else {}
engine = create_engine(DATABASE_URL, connect_args=connect_args)
SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False)

class Base(DeclarativeBase): pass

class User(Base):
    __tablename__ = "users"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    full_name: Mapped[str] = mapped_column(String(160))
    email: Mapped[str] = mapped_column(String(255), unique=True, index=True)
    password_hash: Mapped[str] = mapped_column(String(255))
    role: Mapped[str] = mapped_column(String(50), default="Patient")
    patient_id: Mapped[Optional[str]] = mapped_column(String(40), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

class Doctor(Base):
    __tablename__ = "doctors"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(160))
    specialization: Mapped[str] = mapped_column(String(120))
    hospital: Mapped[str] = mapped_column(String(180), default="Demo Hospital")
    department: Mapped[str] = mapped_column(String(120), default="General")
    fee_inr: Mapped[int] = mapped_column(Integer, default=0)
    status: Mapped[str] = mapped_column(String(40), default="Schedule not verified")
    user_id: Mapped[Optional[int]] = mapped_column(ForeignKey("users.id"), nullable=True)

class Appointment(Base):
    __tablename__ = "appointments"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    patient_id: Mapped[int] = mapped_column(ForeignKey("users.id"), index=True)
    doctor_id: Mapped[int] = mapped_column(ForeignKey("doctors.id"), index=True)
    appointment_at: Mapped[str] = mapped_column(String(40), index=True)
    reason: Mapped[str] = mapped_column(String(500), default="")
    status: Mapped[str] = mapped_column(String(40), default="Pending")
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

class MedicalRecord(Base):
    __tablename__ = "medical_records"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    patient_id: Mapped[int] = mapped_column(ForeignKey("users.id"), index=True)
    title: Mapped[str] = mapped_column(String(180))
    record_type: Mapped[str] = mapped_column(String(80), default="Document")
    issue_date: Mapped[str] = mapped_column(String(40))
    author: Mapped[str] = mapped_column(String(160))
    verification_status: Mapped[str] = mapped_column(String(60), default="Unverified")
    notes: Mapped[str] = mapped_column(Text, default="")
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

class Emergency(Base):
    __tablename__ = "emergencies"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    patient_id: Mapped[Optional[int]] = mapped_column(ForeignKey("users.id"), nullable=True)
    created_by: Mapped[int] = mapped_column(ForeignKey("users.id"))
    summary: Mapped[str] = mapped_column(String(500))
    urgency: Mapped[str] = mapped_column(String(30), default="Urgent")
    status: Mapped[str] = mapped_column(String(40), default="Created")
    assigned_team: Mapped[str] = mapped_column(String(180), default="Unassigned")
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

class AuditEvent(Base):
    __tablename__ = "audit_events"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    actor_id: Mapped[Optional[int]] = mapped_column(Integer, nullable=True)
    action: Mapped[str] = mapped_column(String(120))
    resource_type: Mapped[str] = mapped_column(String(80))
    resource_id: Mapped[Optional[str]] = mapped_column(String(80), nullable=True)
    detail: Mapped[str] = mapped_column(String(500), default="")
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

Base.metadata.create_all(bind=engine)
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/api/auth/login")
app = FastAPI(title="MedShield API", version="1.0.0")
origins = [x.strip() for x in os.getenv("CORS_ORIGINS", "http://localhost:5173").split(",")]
app.add_middleware(CORSMiddleware, allow_origins=origins, allow_credentials=True, allow_methods=["*"], allow_headers=["*"])

def db_session():
    db = SessionLocal()
    try: yield db
    finally: db.close()

def audit(db: Session, actor: Optional[int], action: str, resource: str, rid=None, detail=""):
    db.add(AuditEvent(actor_id=actor, action=action, resource_type=resource, resource_id=str(rid) if rid is not None else None, detail=detail[:500]))
    db.commit()

def user_dict(u: User):
    return {"id":u.id,"full_name":u.full_name,"email":u.email,"role":u.role,"patient_id":u.patient_id}

def current_user(token: str = Depends(oauth2_scheme), db: Session = Depends(db_session)):
    try:
        payload = jwt.decode(token, JWT_SECRET, algorithms=[ALGORITHM])
        uid = int(payload.get("sub", "0"))
    except (JWTError, ValueError):
        raise HTTPException(status_code=401, detail="Invalid or expired session")
    user = db.get(User, uid)
    if not user: raise HTTPException(status_code=401, detail="Account not found")
    return user

def require_roles(*roles):
    def checker(user: User = Depends(current_user)):
        if user.role not in roles: raise HTTPException(status_code=403, detail="Insufficient permissions")
        return user
    return checker

class RegisterIn(BaseModel):
    full_name: str = Field(min_length=2, max_length=160)
    email: EmailStr
    password: str = Field(min_length=8, max_length=128)
    role: str = "Patient"
class DoctorIn(BaseModel):
    name: str = Field(min_length=2, max_length=160)
    specialization: str
    hospital: str = "Demo Hospital"
    department: str = "General"
    fee_inr: int = Field(default=0, ge=0)
class AppointmentIn(BaseModel):
    doctor_id: int
    appointment_at: str
    reason: str = Field(default="", max_length=500)
class AppointmentPatch(BaseModel):
    status: str
    appointment_at: Optional[str] = None
class RecordIn(BaseModel):
    patient_id: Optional[int] = None
    title: str = Field(min_length=2, max_length=180)
    record_type: str = "Document"
    issue_date: str
    author: str = "Patient upload"
    verification_status: str = "Unverified"
    notes: str = ""
class EmergencyIn(BaseModel):
    patient_id: Optional[int] = None
    summary: str = Field(min_length=3, max_length=500)
    urgency: str = "Urgent"
class EmergencyPatch(BaseModel):
    status: str
    assigned_team: Optional[str] = None

@app.get("/api/health")
def health(): return {"status":"ok","service":"MedShield API","mode":"local demo"}

@app.post("/api/auth/register")
def register(body: RegisterIn, db: Session = Depends(db_session)):
    allowed = {"Patient","Doctor","Hospital Staff","Hospital Administrator","Platform Security Administrator"}
    if body.role not in allowed: raise HTTPException(400, "Unsupported role")
    email = body.email.lower()
    if db.query(User).filter(User.email == email).first(): raise HTTPException(409, "Email already registered")
    # Demo only: privileged role selection is allowed locally. Disable it for public registration in production.
    u = User(full_name=body.full_name.strip(), email=email, password_hash=pwd_context.hash(body.password),
             role=body.role, patient_id=f"MS-{int(datetime.now().timestamp())}" if body.role=="Patient" else None)
    db.add(u); db.commit(); db.refresh(u)
    audit(db, u.id, "ACCOUNT_CREATED", "user", u.id, f"Role: {u.role}")
    return user_dict(u)

@app.post("/api/auth/login")
def login(form: OAuth2PasswordRequestForm = Depends(), db: Session = Depends(db_session)):
    u = db.query(User).filter(User.email == form.username.lower()).first()
    if not u or not pwd_context.verify(form.password, u.password_hash):
        audit(db, None, "LOGIN_FAILED", "authentication", None, "Invalid credentials")
        raise HTTPException(status_code=401, detail="Incorrect email or password")
    token = jwt.encode({"sub":str(u.id),"exp":datetime.now(timezone.utc)+timedelta(minutes=TOKEN_MINUTES)}, JWT_SECRET, algorithm=ALGORITHM)
    audit(db, u.id, "LOGIN_SUCCESS", "authentication", u.id, "Session created")
    return {"access_token":token,"token_type":"bearer","user":user_dict(u)}

@app.get("/api/auth/me")
def me(user: User = Depends(current_user)): return user_dict(user)

@app.get("/api/doctors")
def list_doctors(q: str = "", specialization: str = "", db: Session = Depends(db_session), user: User = Depends(current_user)):
    query = db.query(Doctor)
    if q: query = query.filter(Doctor.name.ilike(f"%{q}%"))
    if specialization: query = query.filter(Doctor.specialization.ilike(f"%{specialization}%"))
    return [{"id":d.id,"name":d.name,"specialization":d.specialization,"hospital":d.hospital,"department":d.department,"fee_inr":d.fee_inr,"status":d.status} for d in query.order_by(Doctor.name).all()]

@app.post("/api/doctors")
def create_doctor(body: DoctorIn, db: Session = Depends(db_session), user: User = Depends(require_roles("Hospital Administrator","Platform Security Administrator","Hospital Staff"))):
    d = Doctor(**body.model_dump(), status="Schedule not verified")
    db.add(d); db.commit(); db.refresh(d)
    audit(db, user.id, "DOCTOR_CREATED", "doctor", d.id)
    return {"id":d.id,"name":d.name,"specialization":d.specialization,"hospital":d.hospital,"department":d.department,"fee_inr":d.fee_inr,"status":d.status}

@app.get("/api/appointments")
def list_appointments(db: Session = Depends(db_session), user: User = Depends(current_user)):
    q = db.query(Appointment)
    if user.role == "Patient": q = q.filter(Appointment.patient_id == user.id)
    elif user.role == "Doctor":
        doctor = db.query(Doctor).filter(Doctor.user_id == user.id).first()
        if doctor: q = q.filter(Appointment.doctor_id == doctor.id)
        else: return []
    return [appointment_dict(a, db) for a in q.order_by(Appointment.appointment_at.desc()).all()]

def appointment_dict(a: Appointment, db: Session):
    patient = db.get(User, a.patient_id); doctor = db.get(Doctor, a.doctor_id)
    return {"id":a.id,"patient_id":a.patient_id,"patient_name":patient.full_name if patient else "Unknown",
            "doctor_id":a.doctor_id,"doctor_name":doctor.name if doctor else "Unknown",
            "appointment_at":a.appointment_at,"reason":a.reason,"status":a.status}

@app.post("/api/appointments")
def create_appointment(body: AppointmentIn, db: Session = Depends(db_session), user: User = Depends(current_user)):
    if user.role != "Patient": raise HTTPException(403, "Only patients can create a booking")
    doctor = db.get(Doctor, body.doctor_id)
    if not doctor: raise HTTPException(404, "Doctor not found")
    # Atomic conflict check in local demo; production should add a unique/exclusion constraint and transaction isolation.
    conflict = db.query(Appointment).filter(Appointment.doctor_id==body.doctor_id, Appointment.appointment_at==body.appointment_at, Appointment.status.notin_(["Cancelled"])).first()
    if conflict: raise HTTPException(409, "This doctor slot is already booked")
    a = Appointment(patient_id=user.id, doctor_id=body.doctor_id, appointment_at=body.appointment_at, reason=body.reason, status="Confirmed")
    db.add(a); db.commit(); db.refresh(a)
    audit(db, user.id, "APPOINTMENT_BOOKED", "appointment", a.id)
    return appointment_dict(a, db)

@app.patch("/api/appointments/{appointment_id}")
def patch_appointment(appointment_id: int, body: AppointmentPatch, db: Session = Depends(db_session), user: User = Depends(current_user)):
    a = db.get(Appointment, appointment_id)
    if not a: raise HTTPException(404, "Appointment not found")
    if user.role == "Patient" and a.patient_id != user.id: raise HTTPException(403, "Not your appointment")
    if user.role == "Patient" and body.status not in {"Cancelled"}: raise HTTPException(403, "Patients may only cancel appointments")
    if user.role not in {"Patient","Doctor","Hospital Staff","Hospital Administrator","Platform Security Administrator"}: raise HTTPException(403, "Not authorized")
    if body.appointment_at:
        conflict = db.query(Appointment).filter(Appointment.doctor_id==a.doctor_id, Appointment.appointment_at==body.appointment_at, Appointment.id!=a.id, Appointment.status.notin_(["Cancelled"])).first()
        if conflict: raise HTTPException(409, "This doctor slot is already booked")
        a.appointment_at = body.appointment_at
    allowed = {"Pending","Confirmed","Checked In","In Consultation","Completed","Cancelled","No Show"}
    if body.status not in allowed: raise HTTPException(400, "Invalid appointment status")
    a.status=body.status; db.commit()
    audit(db, user.id, "APPOINTMENT_UPDATED", "appointment", a.id, body.status)
    return appointment_dict(a, db)

@app.get("/api/records")
def list_records(db: Session = Depends(db_session), user: User = Depends(current_user)):
    q = db.query(MedicalRecord)
    if user.role == "Patient": q = q.filter(MedicalRecord.patient_id == user.id)
    elif user.role not in {"Doctor","Hospital Staff","Hospital Administrator","Platform Security Administrator"}: return []
    return [{"id":r.id,"patient_id":r.patient_id,"title":r.title,"record_type":r.record_type,"issue_date":r.issue_date,"author":r.author,"verification_status":r.verification_status,"notes":r.notes} for r in q.order_by(MedicalRecord.created_at.desc()).all()]

@app.post("/api/records")
def create_record(body: RecordIn, db: Session = Depends(db_session), user: User = Depends(current_user)):
    patient_id = body.patient_id if body.patient_id and user.role in {"Doctor","Hospital Staff","Hospital Administrator","Platform Security Administrator"} else user.id
    if patient_id != user.id and user.role not in {"Doctor","Hospital Staff","Hospital Administrator","Platform Security Administrator"}: raise HTTPException(403, "Not authorized")
    if not db.get(User, patient_id): raise HTTPException(404, "Patient account not found")
    r = MedicalRecord(patient_id=patient_id, title=body.title, record_type=body.record_type, issue_date=body.issue_date, author=body.author if user.role!="Patient" else user.full_name, verification_status=body.verification_status if user.role!="Patient" else "Unverified", notes=body.notes)
    db.add(r); db.commit(); db.refresh(r)
    audit(db, user.id, "RECORD_CREATED", "medical_record", r.id, "Metadata record created")
    return {"id":r.id,"patient_id":r.patient_id,"title":r.title,"record_type":r.record_type,"issue_date":r.issue_date,"author":r.author,"verification_status":r.verification_status,"notes":r.notes}

@app.get("/api/emergencies")
def list_emergencies(db: Session = Depends(db_session), user: User = Depends(current_user)):
    q = db.query(Emergency)
    if user.role == "Patient": q = q.filter((Emergency.patient_id==user.id) | (Emergency.created_by==user.id))
    return [{"id":e.id,"patient_id":e.patient_id,"created_by":e.created_by,"summary":e.summary,"urgency":e.urgency,"status":e.status,"assigned_team":e.assigned_team,"created_at":e.created_at.isoformat()} for e in q.order_by(Emergency.created_at.desc()).all()]

@app.post("/api/emergencies")
def create_emergency(body: EmergencyIn, db: Session = Depends(db_session), user: User = Depends(current_user)):
    pid = body.patient_id or (user.id if user.role=="Patient" else None)
    if pid and not db.get(User, pid): raise HTTPException(404, "Patient account not found")
    e = Emergency(patient_id=pid, created_by=user.id, summary=body.summary, urgency=body.urgency, status="Created")
    db.add(e); db.commit(); db.refresh(e)
    audit(db, user.id, "EMERGENCY_CREATED", "emergency", e.id, body.urgency)
    return {"id":e.id,"patient_id":e.patient_id,"created_by":e.created_by,"summary":e.summary,"urgency":e.urgency,"status":e.status,"assigned_team":e.assigned_team,"created_at":e.created_at.isoformat()}

@app.patch("/api/emergencies/{event_id}")
def patch_emergency(event_id: int, body: EmergencyPatch, db: Session = Depends(db_session), user: User = Depends(require_roles("Hospital Staff","Hospital Administrator","Platform Security Administrator"))):
    e = db.get(Emergency, event_id)
    if not e: raise HTTPException(404, "Emergency event not found")
    allowed={"Created","Alerting","Acknowledged","Assigned","In Progress","Resolved","Closed"}
    if body.status not in allowed: raise HTTPException(400, "Invalid emergency status")
    e.status=body.status
    if body.assigned_team is not None: e.assigned_team=body.assigned_team
    db.commit(); audit(db,user.id,"EMERGENCY_UPDATED","emergency",e.id,body.status)
    return {"id":e.id,"status":e.status,"assigned_team":e.assigned_team}

@app.get("/api/audit")
def list_audit(db: Session = Depends(db_session), user: User = Depends(require_roles("Hospital Administrator","Platform Security Administrator"))):
    events=db.query(AuditEvent).order_by(AuditEvent.created_at.desc()).limit(200).all()
    return [{"id":e.id,"actor_id":e.actor_id,"action":e.action,"resource_type":e.resource_type,"resource_id":e.resource_id,"detail":e.detail,"created_at":e.created_at.isoformat()} for e in events]
