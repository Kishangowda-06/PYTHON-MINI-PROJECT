# Deployment guide (draft)
1. Provision PostgreSQL and set DATABASE_URL.
2. Set a strong JWT_SECRET, CORS_ORIGINS, and ENVIRONMENT=production.
3. Use HTTPS everywhere; enable HSTS at the reverse proxy.
4. Configure private object storage (S3-compatible) for medical files; never use public buckets.
5. Run Alembic migrations: alembic upgrade head.
6. Run backend with multiple uvicorn workers behind nginx/ALB.
7. Build frontend: npm run build; serve statically via CDN/nginx.
8. Enable rate limiting, WAF, logging, backups, and incident-response runbooks.
9. Never ship hardcoded admin credentials; create the first admin via a secure one-time bootstrap flow.
