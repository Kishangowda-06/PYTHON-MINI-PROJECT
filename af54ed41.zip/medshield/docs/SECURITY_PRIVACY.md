# Security and privacy configuration guide (draft)
- Encryption in transit (TLS) and at rest via infrastructure-level encryption.
- Least-privilege RBAC enforced server-side.
- Tenant isolation: hospital-scoped queries; cross-hospital access denied by default.
- Audit logging for sensitive actions (record access, emergency break-glass, role changes).
- Session tokens in sessionStorage on the frontend; never localStorage for tokens.
- Rate limiting and input validation on all sensitive endpoints.
- DPDP Act and Indian healthcare compliance require qualified legal review before production.
