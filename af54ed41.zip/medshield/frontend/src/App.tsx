import { Routes, Route, Link, useNavigate } from 'react-router-dom'
import { useState } from 'react'
import { Menu, X, ShieldCheck, LogOut } from 'lucide-react'
import Home from './pages/Home'
import Login from './pages/Login'
import Register from './pages/Register'
import PatientDashboard from './pages/PatientDashboard'
import DoctorDashboard from './pages/DoctorDashboard'
import AdminDashboard from './pages/AdminDashboard'
import SecurityDashboard from './pages/SecurityDashboard'
import { getRole, clearSession } from './api'

export default function App() {
  const [open, setOpen] = useState(false)
  const role = getRole()
  const nav = useNavigate()
  const links: [string,string][] = [["Home","/"],["Platform","/#platform"],["For Patients","/#patients"],["For Doctors","/#doctors"],["For Hospitals","/#hospitals"],["Security","/#security"],["Pricing","/#pricing"]]
  return (
    <div className="min-h-screen bg-slate-50 text-slate-900">
      <header className="sticky top-0 z-40 bg-white/90 backdrop-blur border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 h-16 flex items-center justify-between">
          <Link to="/" className="flex items-center gap-2 font-semibold text-navy"><ShieldCheck className="text-teal"/>MedShield</Link>
          <nav className="hidden md:flex gap-6 text-sm">
            {links.map(([l,h]) => <a key={l} href={h} className="hover:text-teal">{l}</a>)}
          </nav>
          <div className="hidden md:flex items-center gap-3">
            {role ? (
              <>
                <Link to={'/'+role+'-dashboard'} className="text-sm font-medium text-teal">Dashboard</Link>
                <button onClick={()=>{clearSession(); nav('/')}} className="flex items-center gap-1 text-sm"><LogOut size={16}/>Sign out</button>
              </>
            ) : (
              <>
                <Link to="/login" className="text-sm">Sign In</Link>
                <Link to="/register" className="px-4 py-2 rounded-lg bg-navy text-white text-sm">Get Started</Link>
              </>
            )}
          </div>
          <button className="md:hidden" onClick={()=>setOpen(!open)}>{open?<X/>:<Menu/>}</button>
        </div>
        {open && (
          <div className="md:hidden border-t bg-white p-4 space-y-2">
            {links.map(([l,h]) => <a key={l} href={h} className="block py-2" onClick={()=>setOpen(false)}>{l}</a>)}
            <Link to="/login" className="block py-2">Sign In</Link>
            <Link to="/register" className="block py-2 font-medium text-teal">Get Started</Link>
          </div>
        )}
      </header>
      <Routes>
        <Route path="/" element={<Home/>}/>
        <Route path="/login" element={<Login/>}/>
        <Route path="/register" element={<Register/>}/>
        <Route path="/patient-dashboard" element={<PatientDashboard/>}/>
        <Route path="/doctor-dashboard" element={<DoctorDashboard/>}/>
        <Route path="/hospital_admin-dashboard" element={<AdminDashboard/>}/>
        <Route path="/security_admin-dashboard" element={<SecurityDashboard/>}/>
      </Routes>
      <footer className="border-t bg-white py-8 text-sm text-slate-500">
        <div className="max-w-7xl mx-auto px-4">MedShield - Your Health. Your Data. Protected. Draft legal pages require review before production.</div>
      </footer>
    </div>
  )
}
