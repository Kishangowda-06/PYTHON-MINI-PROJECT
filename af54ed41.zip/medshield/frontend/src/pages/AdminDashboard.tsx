import { useQuery } from '@tanstack/react-query'
import { api } from '../api'
export default function AdminDashboard(){
  const doctors = useQuery({queryKey:['doctors'], queryFn:()=>api.get('/doctors').then(r=>r.data)})
  return (<main className="max-w-7xl mx-auto px-4 py-10">
    <h1 className="text-3xl font-bold text-navy">Hospital administration</h1>
    <div className="grid md:grid-cols-4 gap-6 mt-8">
      {[["Active doctors",doctors.data?.length??0],["Departments","-"],["Emergency alerts","-"],["Security events","-"]].map(([l,v])=>
      <div key={l as string} className="bg-white rounded-2xl p-6 border shadow-sm"><p className="text-sm text-slate-500">{l}</p><p className="text-3xl font-bold text-navy mt-2">{v as any}</p></div>)}
    </div>
    <div className="mt-8 bg-white rounded-2xl p-6 border shadow-sm">
      <h3 className="font-semibold">Doctor directory</h3>
      <table className="w-full text-sm mt-3"><thead><tr className="text-left text-slate-500"><th className="py-2">Doctor</th><th>Specialization</th><th>Status</th><th>Verification</th></tr></thead>
      <tbody>{doctors.data?.map((d:any)=><tr key={d.id} className="border-t"><td className="py-2">{d.full_name}</td><td>{d.specialization}</td><td>{d.live_status}</td><td>{d.verification_status}</td></tr>)}</tbody></table>
    </div>
  </main>)
}
