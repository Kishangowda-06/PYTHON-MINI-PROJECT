import { useState } from 'react'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { api } from '../api'
import { Siren, CalendarCheck, FileLock } from 'lucide-react'
export default function PatientDashboard(){
  const qc = useQueryClient()
  const doctors = useQuery({queryKey:['doctors'], queryFn:()=>api.get('/doctors').then(r=>r.data)})
  const appts = useQuery({queryKey:['appts'], queryFn:()=>api.get('/appointments').then(r=>r.data)})
  const notes = useQuery({queryKey:['notes'], queryFn:()=>api.get('/notifications').then(r=>r.data)})
  const [slot,setSlot]=useState(''); const [reason,setReason]=useState('')
  const book = useMutation({mutationFn:()=>api.post('/appointments',{slot_id:slot,reason}), onSuccess:()=>qc.invalidateQueries({queryKey:['appts']})})
  const emergency = useMutation({mutationFn:()=>api.post('/emergency',{description:'Patient-initiated emergency request (demo)',urgency:'high'}), onSuccess:()=>qc.invalidateQueries({queryKey:['notes']})})
  const firstDoctor = doctors.data?.[0]
  const slots = useQuery({queryKey:['slots',firstDoctor?.id], enabled:!!firstDoctor, queryFn:()=>api.get('/doctors/'+firstDoctor.id+'/slots').then(r=>r.data)})
  return (<main className="max-w-7xl mx-auto px-4 py-10">
    <h1 className="text-3xl font-bold text-navy">Patient dashboard</h1>
    <div className="grid md:grid-cols-3 gap-6 mt-8">
      <div className="bg-white rounded-2xl p-6 border shadow-sm"><CalendarCheck className="text-teal mb-2"/><h3 className="font-semibold">Appointments</h3>
        <ul className="mt-3 space-y-2 text-sm">{appts.data?.length ? appts.data.map((a:any)=><li key={a.id} className="flex justify-between border-b pb-1"><span>{a.reason}</span><span className="text-teal">{a.status}</span></li>) : <li className="text-slate-500">No appointments yet.</li>}</ul></div>
      <div className="bg-white rounded-2xl p-6 border shadow-sm"><FileLock className="text-teal mb-2"/><h3 className="font-semibold">Book appointment</h3>
        <select className="w-full border rounded-lg p-2 mt-3" onChange={e=>setSlot(e.target.value)} value={slot}>
          <option value="">Select slot</option>
          {slots.data?.map((s:any)=><option key={s.id} value={s.id}>{new Date(s.starts_at).toLocaleString()}</option>)}
        </select>
        <input className="w-full border rounded-lg p-2 mt-2" placeholder="Reason for visit" value={reason} onChange={e=>setReason(e.target.value)}/>
        <button disabled={!slot||!reason} onClick={()=>book.mutate()} className="w-full mt-3 py-2 rounded-xl bg-navy text-white disabled:opacity-50">Confirm booking</button>
        {book.isSuccess && <p className="text-green-600 text-sm mt-2">Appointment confirmed.</p>}</div>
      <div className="bg-red-50 border border-red-200 rounded-2xl p-6"><Siren className="text-red-600 mb-2"/><h3 className="font-semibold text-red-700">Emergency</h3>
        <p className="text-sm text-red-700 mt-2">For immediate help in India, call <strong>112</strong>. MedShield is not a substitute for emergency services.</p>
        <button onClick={()=>emergency.mutate()} className="mt-3 w-full py-2 rounded-xl bg-red-600 text-white">Raise emergency alert</button>
        {emergency.isSuccess && <p className="text-sm mt-2">Alert created (demo delivery mode).</p>}</div>
    </div>
    <div className="mt-8 bg-white rounded-2xl p-6 border shadow-sm">
      <h3 className="font-semibold">Notifications</h3>
      <ul className="mt-3 text-sm space-y-2">{notes.data?.length ? notes.data.map((n:any)=><li key={n.id} className={n.read?'text-slate-500':'font-medium'}>{n.message}</li>) : <li className="text-slate-500">No notifications.</li>}</ul>
    </div>
  </main>)
}
