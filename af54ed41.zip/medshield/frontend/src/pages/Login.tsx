import { useState } from 'react'
import { useNavigate, Link } from 'react-router-dom'
import { api, saveSession } from '../api'
export default function Login(){
  const [email,setEmail]=useState(''); const [password,setPassword]=useState(''); const [err,setErr]=useState(''); const nav=useNavigate()
  async function submit(e:any){ e.preventDefault(); setErr('')
    try { const r = await api.post('/auth/login',{email,password}); saveSession(r.data.access_token,r.data.role,r.data.full_name); nav('/'+r.data.role+'-dashboard') }
    catch(e:any){ setErr(e.response?.data?.detail || 'Login failed') } }
  return (<main className="max-w-md mx-auto px-4 py-16">
    <h1 className="text-2xl font-bold text-navy">Sign in</h1>
    <form onSubmit={submit} className="mt-6 space-y-4 bg-white p-6 rounded-2xl border shadow-sm">
      <input className="w-full border rounded-lg p-3" placeholder="Email" value={email} onChange={e=>setEmail(e.target.value)} required/>
      <input className="w-full border rounded-lg p-3" type="password" placeholder="Password" value={password} onChange={e=>setPassword(e.target.value)} required/>
      {err && <p className="text-red-600 text-sm">{err}</p>}
      <button className="w-full py-3 rounded-xl bg-navy text-white">Sign in</button>
      <p className="text-sm text-slate-600">No account? <Link to="/register" className="text-teal">Register</Link></p>
    </form></main>)
}
