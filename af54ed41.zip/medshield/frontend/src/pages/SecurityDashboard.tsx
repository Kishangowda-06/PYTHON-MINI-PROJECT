import { useQuery } from '@tanstack/react-query'
import { api } from '../api'
export default function SecurityDashboard(){
  const events = useQuery({queryKey:['sec'], queryFn:()=>api.get('/security/events').then(r=>r.data)})
  return (<main className="max-w-7xl mx-auto px-4 py-10">
    <h1 className="text-3xl font-bold text-navy">Security administration</h1>
    <div className="mt-8 bg-white rounded-2xl p-6 border shadow-sm">
      <h3 className="font-semibold">Security events</h3>
      <ul className="mt-3 text-sm space-y-2">{events.data?.length ? events.data.map((e:any)=><li key={e.id} className="border-b pb-2"><span className={'font-medium '+(e.severity==='high'?'text-red-600':'text-slate-700')}>{e.severity}</span> - {e.event_type} - {e.detail}</li>) : <li className="text-slate-500">No security events.</li>}</ul>
    </div>
  </main>)
}
