import { Link } from 'react-router-dom'
import { ShieldCheck, CalendarCheck, FileLock, Siren, Stethoscope, Building2 } from 'lucide-react'

const features = [
  {icon:CalendarCheck, t:"Patient appointment booking", d:"Find doctors and book confirmed slots."},
  {icon:Stethoscope, t:"Doctor discovery", d:"Search by specialization, hospital and availability."},
  {icon:FileLock, t:"Secure health records", d:"Private, hash-verified medical documents."},
  {icon:ShieldCheck, t:"AI-powered security monitoring", d:"Explainable alerts for suspicious access."},
  {icon:Siren, t:"Emergency coordination", d:"Time-bound, audited break-glass access."},
  {icon:Building2, t:"Hospital operations", d:"Schedules, staff and department analytics."},
]
export default function Home(){
  return (<main>
    <section className="bg-gradient-to-b from-navy to-slate-900 text-white">
      <div className="max-w-7xl mx-auto px-4 py-20 grid md:grid-cols-2 gap-10 items-center">
        <div>
          <p className="text-teal font-medium mb-3">AI-powered healthcare security</p>
          <h1 className="text-4xl md:text-5xl font-bold leading-tight">Healthcare, Connected.<br/>Medical Data, Protected.</h1>
          <p className="mt-4 text-slate-300">Manage appointments, find available doctors, access medical records securely, and coordinate emergency care through one intelligent healthcare platform.</p>
          <div className="mt-8 flex gap-3">
            <Link to="/register" className="px-6 py-3 rounded-xl bg-teal font-medium">Get Started</Link>
            <a href="#platform" className="px-6 py-3 rounded-xl border border-white/30">Explore the Platform</a>
          </div>
        </div>
        <div className="bg-white/5 border border-white/10 rounded-2xl p-6">
          <div className="text-sm text-slate-300 mb-4">Product preview</div>
          <div className="space-y-3">
            <div className="bg-white/10 rounded-xl p-4">Next appointment - Dr. Demo Rao - Tomorrow 10:00</div>
            <div className="bg-white/10 rounded-xl p-4">Record security - 3 documents hash-verified</div>
            <div className="bg-red-500/20 border border-red-400/30 rounded-xl p-4">Emergency alert - Awaiting acknowledgement</div>
          </div>
        </div>
      </div>
    </section>
    <section id="platform" className="max-w-7xl mx-auto px-4 py-16">
      <h2 className="text-3xl font-bold text-navy">Platform features</h2>
      <div className="grid md:grid-cols-3 gap-6 mt-8">
        {features.map(f => (
          <div key={f.t} className="bg-white rounded-2xl p-6 shadow-sm border">
            <f.icon className="text-teal mb-3"/><h3 className="font-semibold">{f.t}</h3>
            <p className="text-sm text-slate-600 mt-1">{f.d}</p>
          </div>
        ))}
      </div>
    </section>
    <section id="security" className="bg-white border-y py-16">
      <div className="max-w-7xl mx-auto px-4">
        <h2 className="text-3xl font-bold text-navy">Security and privacy</h2>
        <p className="mt-3 text-slate-600 max-w-3xl">Identity verification, least-privilege access, document integrity checks, suspicious activity monitoring, encryption in transit, and auditable emergency access. MedShield does not claim absolute security or certification without independent verification.</p>
      </div>
    </section>
    <section id="pricing" className="max-w-7xl mx-auto px-4 py-16">
      <h2 className="text-3xl font-bold text-navy">Pricing</h2>
      <div className="grid md:grid-cols-4 gap-6 mt-8">
        {["Individual","Professional","Hospital","Enterprise"].map(t => (
          <div key={t} className="bg-white rounded-2xl p-6 border shadow-sm">
            <h3 className="font-semibold">{t}</h3>
            <p className="text-2xl font-bold text-navy mt-2">{t==="Individual"?"Free":"Contact Sales"}</p>
            <p className="text-sm text-slate-600 mt-2">Configurable plan. Pricing set by business owner.</p>
          </div>
        ))}
      </div>
    </section>
  </main>)
}
