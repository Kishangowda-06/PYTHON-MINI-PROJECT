import { useState } from 'react'
import { useNavigate, Link } from 'react-router-dom'
import { api, saveSession } from '../api'
export default function Register(){
  const [f,setF]=useState({full_name:'',email:'',password:'',role:'patient',date_of_birth:''}); const [err,setErr]=useState(''); const nav=useNavigate()
  async function submit(e:any){ e.preventDefault(); setErr('')
    try { const r = await api.post('/auth/register',f); saveSession(r.data.access_token,r.data.role,r.data.full_name); nav('/'+r.data.role+'-dashboard') }
    catch(e:any){ setErr(e.response?.data?.detail || 'Registration failed') } }
  return (<main className="max-w-md mx-auto px-4 py-16">
    <h1 className="text-2xl font-bold text-navy">Create your MedShield account</h1>
    <form onSubmit={submit} className="mt-6 space-y-4 bg-white p-6 rounded-2xl border shadow-sm">
      <input className="w-full border rounded-lg p-3" placeholder="Full name" value={f.full_name} onChange={e=>setF({...f,full_name:e.target.value})} required/>
      <input className="w-full border rounded-lg p-3" placeholder="Email" type="email" value={f.email} onChange={e=>setF({...f,email:e.target.value})} required/>
      <input className="w-full border rounded-lg p-3" placeholder="Password (min 8 chars)" type="password" value={f.password} onChange={e=>setF({...f,password:e.target.value})} required/>
      <select className="w-full border rounded-lg p-3" value={f.role} onChange={e=>setF({...f,role:e.target.value})}>
        <option value="patient">Patient</option><option value="doctor">Doctor</option>
      </select>
      {f.role==='patient' && <input className="w-full border rounded-lg p-3" placeholder="Date of birth" type="date" value={f.date_of_birth} onChange={e=>setF({...f,date_of_birth:e.target.value})}/>}
      {err && <p className="text-red-600 text-sm">{err}</p>}
      <button className="w-full py-3 rounded-xl bg-teal text-white">Create account</button>
      <p className="text-sm text-slate-600">Already registered? <Link to="/login" className="text-teal">Sign in</Link></p>
    </form></main>)
}
