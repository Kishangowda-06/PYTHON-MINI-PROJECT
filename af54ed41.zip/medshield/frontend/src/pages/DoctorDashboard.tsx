import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { useState } from 'react'
import { api } from '../api'
export default function DoctorDashboard(){
  const qc = useQueryClient()
  const appts = useQuery({queryKey:['appts'], queryFn:()=>api.get('/appointments').then(r=>r.data)})
  const [selected,setSelected]=useState(''); const [form,setForm]=useState({symptoms:'',findings:'',diagnosis:''})
  const encounter = useMutation({mutationFn:()=>api.post('/records/encounter',{appointment_id:selected,...form}), onSuccess:()=>qc.invalidateQueries({queryKey:['appts']})})
  return (<main className="max-w-7xl mx-auto px-4 py-10">
    <h1 className="text-3xl font-bold text-navy">Doctor workspace</h1>
    <div className="grid md:grid-cols-2 gap-6 mt-8">
      <div className="bg-white rounded-2xl p-6 border shadow-sm">
        <h3 className="font-semibold">Appointments</h3>
        <ul className="mt-3 text-sm space-y-2">{appts.data?.length ? appts.data.map((a:any)=><li key={a.id} className="flex justify-between border-b pb-1"><span>{a.reason}</span><button onClick={()=>setSelected(a.id)} className="text-teal">{a.status==='completed'?'Completed':'Open'}</button></li>) : <li className="text-slate-500">No appointments assigned.</li>}</ul>
      </div>
      <div className="bg-white rounded-2xl p-6 border shadow-sm">
        <h3 className="font-semibold">Consultation record</h3>
        <textarea className="w-full border rounded-lg p-2 mt-3" placeholder="Symptoms" value={form.symptoms} onChange={e=>setForm({...form,symptoms:e.target.value})}/>
        <textarea className="w-full border rounded-lg p-2 mt-2" placeholder="Findings" value={form.findings} onChange={e=>setForm({...form,findings:e.target.value})}/>
        <textarea className="w-full border rounded-lg p-2 mt-2" placeholder="Diagnosis" value={form.diagnosis} onChange={e=>setForm({...form,diagnosis:e.target.value})}/>
        <button disabled={!selected} onClick={()=>encounter.mutate()} className="w-full mt-3 py-2 rounded-xl bg-teal text-white disabled:opacity-50">Save encounter</button>
        {encounter.isSuccess && <p className="text-green-600 text-sm mt-2">Encounter saved and appointment completed.</p>}
      </div>
    </div>
  </main>)
}
