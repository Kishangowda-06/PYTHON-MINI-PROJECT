import axios from 'axios'
export const api = axios.create({ baseURL: '/api' })
api.interceptors.request.use(cfg => {
  const t = sessionStorage.getItem('medshield_token')
  if (t) cfg.headers.Authorization = 'Bearer ' + t
  return cfg
})
export function saveSession(token: string, role: string, name: string) {
  sessionStorage.setItem('medshield_token', token)
  sessionStorage.setItem('medshield_role', role)
  sessionStorage.setItem('medshield_name', name)
}
export function clearSession() { sessionStorage.clear() }
export function getRole() { return sessionStorage.getItem('medshield_role') }
