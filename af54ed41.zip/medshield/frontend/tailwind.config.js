export default { content:["./index.html","./src/**/*.{ts,tsx}"], darkMode:"class", theme:{extend:{colors:{navy:"#0B1B33",teal:"#0E7C7B",cyan:"#22D3EE"}}}, plugins:[] }
