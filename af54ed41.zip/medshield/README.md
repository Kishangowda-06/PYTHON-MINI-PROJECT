# MedShield

AI-powered healthcare security, smart appointments and emergency medical access.

> Status: functional full-stack MVP scaffold. Not certified or production-ready; obtain legal, clinical and security review before handling real patient data.

## Stack
- Frontend: React + TypeScript + Vite + Tailwind + TanStack Query + React Router
- Backend: FastAPI + SQLAlchemy + JWT auth + role-based authorization
- Database: SQLite for local dev; PostgreSQL recommended for production
- Tests: pytest (backend)

## Quick start
```bash
cd backend
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
uvicorn app.main:app --reload
python seed.py

cd ../frontend
npm install
npm run dev
```
- Frontend: http://localhost:5173
- API docs: http://localhost:8000/api/docs

## Demo logins (after seeding)
- Hospital admin: admin@demo.medshield / Admin@12345
- Doctor: doctor@demo.medshield / Doctor@12345

## Tests
```bash
cd backend && pytest
```

## Safety notes
- Emergency features run in demo mode unless live notification/dispatch integrations are configured. In India, call 112 for immediate emergencies.
- Document verification is hash/integrity based and does not prove clinical authenticity.
- Legal pages and compliance claims require qualified legal review, including DPDP Act considerations in India.
