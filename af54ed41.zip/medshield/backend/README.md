# MedShield Backend
FastAPI + SQLAlchemy backend.
## Setup
cd backend
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
uvicorn app.main:app --reload
python seed.py
pytest
API docs: http://localhost:8000/api/docs
