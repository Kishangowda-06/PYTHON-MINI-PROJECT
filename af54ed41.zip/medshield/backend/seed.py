# Development-only demo seed. Creates clearly fictional data.
from app.database import SessionLocal, engine, Base
from app import models, security
import datetime as dt
Base.metadata.create_all(bind=engine)
db = SessionLocal()
if not db.query(models.User).filter_by(email="admin@demo.medshield").first():
    h = models.Hospital(name="Demo City Hospital (FICTIONAL)", location="Demo, India"); db.add(h); db.flush()
    dep = models.Department(hospital_id=h.id, name="General Medicine"); db.add(dep); db.flush()
    admin = models.User(email="admin@demo.medshield", hashed_password=security.hash_password("Admin@12345"), full_name="Demo Hospital Admin", role="hospital_admin"); db.add(admin)
    doc_user = models.User(email="doctor@demo.medshield", hashed_password=security.hash_password("Doctor@12345"), full_name="Dr. Demo Rao", role="doctor"); db.add(doc_user); db.flush()
    doc = models.DoctorProfile(user_id=doc_user.id, hospital_id=h.id, department_id=dep.id, specialization="General Medicine", verification_status="verified", live_status="available", consultation_fee=500); db.add(doc); db.flush()
    base = dt.datetime.utcnow().replace(minute=0, second=0, microsecond=0) + dt.timedelta(days=1)
    for i in range(8):
        db.add(models.AppointmentSlot(doctor_id=doc.id, starts_at=base+dt.timedelta(hours=i), ends_at=base+dt.timedelta(hours=i, minutes=30)))
    db.add(models.SecurityEvent(event_type="failed_login", severity="medium", detail="5 failed logins for demo account", resource="user:demo"))
    db.commit()
print("Demo data seeded. Login: admin@demo.medshield / Admin@12345 ; doctor@demo.medshield / Doctor@12345")
