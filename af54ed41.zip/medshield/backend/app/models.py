import uuid, datetime as dt
from sqlalchemy import (Column, String, DateTime, ForeignKey, Boolean, Integer, Text, Float, UniqueConstraint)
from sqlalchemy.orm import relationship
from .database import Base
def uid(): return uuid.uuid4().hex
def now(): return dt.datetime.utcnow()

class User(Base):
    __tablename__="users"
    id=Column(String, primary_key=True, default=uid)
    email=Column(String, unique=True, nullable=False, index=True)
    hashed_password=Column(String, nullable=False)
    full_name=Column(String, nullable=False)
    role=Column(String, nullable=False, index=True)
    phone=Column(String)
    is_active=Column(Boolean, default=True)
    created_at=Column(DateTime, default=now)
    patient=relationship("PatientProfile", back_populates="user", uselist=False)
    doctor=relationship("DoctorProfile", back_populates="user", uselist=False)

class Hospital(Base):
    __tablename__="hospitals"
    id=Column(String, primary_key=True, default=uid)
    name=Column(String, nullable=False)
    location=Column(String)
    created_at=Column(DateTime, default=now)
    departments=relationship("Department", back_populates="hospital")

class Department(Base):
    __tablename__="departments"
    id=Column(String, primary_key=True, default=uid)
    hospital_id=Column(String, ForeignKey("hospitals.id"))
    name=Column(String, nullable=False)
    hospital=relationship("Hospital", back_populates="departments")

class PatientProfile(Base):
    __tablename__="patient_profiles"
    id=Column(String, primary_key=True, default=uid)
    user_id=Column(String, ForeignKey("users.id"), unique=True)
    medshield_patient_id=Column(String, unique=True, default=lambda: "MS-P-"+uid()[:8].upper())
    date_of_birth=Column(String)
    consent_preferences=Column(Text, default="{}")
    user=relationship("User", back_populates="patient")

class DoctorProfile(Base):
    __tablename__="doctor_profiles"
    id=Column(String, primary_key=True, default=uid)
    user_id=Column(String, ForeignKey("users.id"), unique=True)
    hospital_id=Column(String, ForeignKey("hospitals.id"))
    department_id=Column(String, ForeignKey("departments.id"))
    specialization=Column(String)
    registration_number=Column(String)
    verification_status=Column(String, default="pending")
    live_status=Column(String, default="not_on_duty")
    consultation_fee=Column(Float, default=0)
    status_updated_at=Column(DateTime, default=now)
    user=relationship("User", back_populates="doctor")
    hospital=relationship("Hospital")
    department=relationship("Department")

class DoctorSchedule(Base):
    __tablename__="doctor_schedules"
    id=Column(String, primary_key=True, default=uid)
    doctor_id=Column(String, ForeignKey("doctor_profiles.id"))
    day_of_week=Column(Integer)
    start_time=Column(String)
    end_time=Column(String)
    slot_minutes=Column(Integer, default=30)

class AppointmentSlot(Base):
    __tablename__="appointment_slots"
    id=Column(String, primary_key=True, default=uid)
    doctor_id=Column(String, ForeignKey("doctor_profiles.id"), index=True)
    starts_at=Column(DateTime, index=True)
    ends_at=Column(DateTime)
    is_booked=Column(Boolean, default=False, index=True)
    __table_args__=(UniqueConstraint("doctor_id","starts_at", name="uq_doctor_slot"),)

class Appointment(Base):
    __tablename__="appointments"
    id=Column(String, primary_key=True, default=uid)
    slot_id=Column(String, ForeignKey("appointment_slots.id"), unique=True)
    patient_id=Column(String, ForeignKey("patient_profiles.id"), index=True)
    doctor_id=Column(String, ForeignKey("doctor_profiles.id"), index=True)
    hospital_id=Column(String, ForeignKey("hospitals.id"), index=True)
    reason=Column(Text)
    status=Column(String, default="pending", index=True)
    created_at=Column(DateTime, default=now)
    slot=relationship("AppointmentSlot")
    patient=relationship("PatientProfile")
    doctor=relationship("DoctorProfile")

class EncounterRecord(Base):
    __tablename__="encounter_records"
    id=Column(String, primary_key=True, default=uid)
    appointment_id=Column(String, ForeignKey("appointments.id"))
    patient_id=Column(String, ForeignKey("patient_profiles.id"), index=True)
    doctor_id=Column(String, ForeignKey("doctor_profiles.id"))
    symptoms=Column(Text)
    findings=Column(Text)
    diagnosis=Column(Text)
    treatment_plan=Column(Text)
    follow_up=Column(Text)
    created_at=Column(DateTime, default=now)
    amended_from=Column(String)

class MedicalDocument(Base):
    __tablename__="medical_documents"
    id=Column(String, primary_key=True, default=uid)
    patient_id=Column(String, ForeignKey("patient_profiles.id"), index=True)
    uploaded_by=Column(String, ForeignKey("users.id"))
    record_type=Column(String)
    file_name=Column(String)
    file_hash=Column(String, index=True)
    storage_key=Column(String)
    verification_status=Column(String, default="uploaded")
    created_at=Column(DateTime, default=now)

class EmergencyEvent(Base):
    __tablename__="emergency_events"
    id=Column(String, primary_key=True, default=uid)
    patient_id=Column(String, ForeignKey("patient_profiles.id"), index=True)
    created_by=Column(String, ForeignKey("users.id"))
    description=Column(Text)
    urgency=Column(String, default="medium")
    status=Column(String, default="created", index=True)
    notification_delivery=Column(String, default="demo")
    created_at=Column(DateTime, default=now)
    acknowledged_at=Column(DateTime)
    resolved_at=Column(DateTime)

class RecordAccessGrant(Base):
    __tablename__="record_access_grants"
    id=Column(String, primary_key=True, default=uid)
    patient_id=Column(String, ForeignKey("patient_profiles.id"), index=True)
    clinician_id=Column(String, ForeignKey("users.id"))
    emergency_event_id=Column(String, ForeignKey("emergency_events.id"))
    reason=Column(Text)
    scope=Column(String, default="limited")
    granted_at=Column(DateTime, default=now)
    expires_at=Column(DateTime, nullable=False)
    revoked_at=Column(DateTime)
    approved=Column(Boolean, default=False)

class SecurityEvent(Base):
    __tablename__="security_events"
    id=Column(String, primary_key=True, default=uid)
    user_id=Column(String, ForeignKey("users.id"), nullable=True)
    event_type=Column(String, index=True)
    severity=Column(String, default="low")
    detail=Column(Text)
    resource=Column(String)
    status=Column(String, default="open")
    created_at=Column(DateTime, default=now)

class AuditLog(Base):
    __tablename__="audit_logs"
    id=Column(String, primary_key=True, default=uid)
    actor_id=Column(String, nullable=True)
    action=Column(String, index=True)
    resource=Column(String)
    detail=Column(Text)
    created_at=Column(DateTime, default=now, index=True)

class Notification(Base):
    __tablename__="notifications"
    id=Column(String, primary_key=True, default=uid)
    recipient_id=Column(String, ForeignKey("users.id"), index=True)
    event_type=Column(String)
    message=Column(Text)
    resource=Column(String)
    read=Column(Boolean, default=False)
    created_at=Column(DateTime, default=now)

class SalesInquiry(Base):
    __tablename__="sales_inquiries"
    id=Column(String, primary_key=True, default=uid)
    name=Column(String); email=Column(String); organization=Column(String)
    org_type=Column(String); message=Column(Text)
    consent=Column(Boolean, default=False)
    status=Column(String, default="new")
    created_at=Column(DateTime, default=now)
