import hashlib, datetime as dt
from fastapi import FastAPI, Depends, HTTPException, UploadFile, File, Form
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy.orm import Session
from sqlalchemy.exc import IntegrityError
from .database import get_db, engine, Base
from . import models, schemas, security
from .models import (User, PatientProfile, DoctorProfile, AppointmentSlot, Appointment,
    EncounterRecord, MedicalDocument, EmergencyEvent, RecordAccessGrant, SecurityEvent, AuditLog, Notification, SalesInquiry)
from .config import settings

app = FastAPI(title="MedShield API", version="0.1.0", docs_url="/api/docs")
app.add_middleware(CORSMiddleware, allow_origins=settings.cors_origins.split(","), allow_credentials=True, allow_methods=["*"], allow_headers=["*"])

def audit(db, actor, action, resource, detail=""):
    db.add(AuditLog(actor_id=actor, action=action, resource=resource, detail=detail)); db.commit()
def notify(db, recipient_id, event_type, message, resource=""):
    db.add(Notification(recipient_id=recipient_id, event_type=event_type, message=message, resource=resource)); db.commit()

@app.on_event("startup")
def startup(): Base.metadata.create_all(bind=engine)

@app.post("/api/auth/register", response_model=schemas.TokenOut)
def register(data: schemas.RegisterIn, db: Session = Depends(get_db)):
    if db.query(User).filter(User.email==data.email).first(): raise HTTPException(409, "Email already registered")
    u = User(email=data.email, hashed_password=security.hash_password(data.password), full_name=data.full_name, role=data.role, phone=data.phone)
    db.add(u); db.flush()
    if data.role == "patient":
        db.add(PatientProfile(user_id=u.id, date_of_birth=data.date_of_birth))
    db.commit(); audit(db, u.id, "user.registered", "user:"+u.id)
    return schemas.TokenOut(access_token=security.create_token(u.id, u.role), role=u.role, full_name=u.full_name)

@app.post("/api/auth/login", response_model=schemas.TokenOut)
def login(data: schemas.LoginIn, db: Session = Depends(get_db)):
    u = db.query(User).filter(User.email==data.email).first()
    if not u or not security.verify_password(data.password, u.hashed_password):
        raise HTTPException(401, "Invalid credentials")
    return schemas.TokenOut(access_token=security.create_token(u.id, u.role), role=u.role, full_name=u.full_name)

@app.get("/api/auth/me")
def me(user: User = Depends(security.get_current_user)):
    return {"id": user.id, "email": user.email, "role": user.role, "full_name": user.full_name}

@app.get("/api/doctors", response_model=list[schemas.DoctorOut])
def doctors(db: Session = Depends(get_db), specialization: str = None, q: str = None):
    query = db.query(DoctorProfile).join(User)
    if specialization: query = query.filter(DoctorProfile.specialization.ilike("%"+specialization+"%"))
    if q: query = query.filter(User.full_name.ilike("%"+q+"%"))
    return query.all()

@app.get("/api/doctors/{doctor_id}/slots", response_model=list[schemas.SlotOut])
def slots(doctor_id: str, db: Session = Depends(get_db)):
    return db.query(AppointmentSlot).filter(AppointmentSlot.doctor_id==doctor_id, AppointmentSlot.is_booked==False, AppointmentSlot.starts_at > dt.datetime.utcnow()).order_by(AppointmentSlot.starts_at).limit(50).all()

@app.post("/api/doctors/{doctor_id}/status")
def set_status(doctor_id: str, status: str, user: User = Depends(security.require_roles("doctor","hospital_admin")), db: Session = Depends(get_db)):
    d = db.query(DoctorProfile).get(doctor_id)
    if not d: raise HTTPException(404, "Doctor not found")
    if user.role == "doctor" and d.user_id != user.id: raise HTTPException(403, "Not your profile")
    d.live_status = status; d.status_updated_at = dt.datetime.utcnow(); db.commit()
    audit(db, user.id, "doctor.status_changed", "doctor:"+doctor_id, status)
    return {"ok": True, "status": d.live_status, "updated_at": d.status_updated_at}

@app.post("/api/appointments", response_model=schemas.AppointmentOut)
def book(data: schemas.AppointmentCreate, user: User = Depends(security.require_roles("patient")), db: Session = Depends(get_db)):
    patient = db.query(PatientProfile).filter(PatientProfile.user_id==user.id).first()
    slot = db.query(AppointmentSlot).with_for_update().get(data.slot_id)
    if not slot or slot.is_booked: raise HTTPException(409, "Slot no longer available")
    slot.is_booked = True
    doctor = db.query(DoctorProfile).get(slot.doctor_id)
    appt = Appointment(slot_id=slot.id, patient_id=patient.id, doctor_id=slot.doctor_id, hospital_id=doctor.hospital_id, reason=data.reason, status="confirmed")
    db.add(appt)
    try: db.commit()
    except IntegrityError: db.rollback(); raise HTTPException(409, "Booking conflict")
    notify(db, user.id, "appointment.booked", "Your appointment is confirmed.", appt.id)
    audit(db, user.id, "appointment.booked", "appointment:"+appt.id)
    return appt

@app.get("/api/appointments")
def my_appointments(user: User = Depends(security.get_current_user), db: Session = Depends(get_db)):
    q = db.query(Appointment)
    if user.role == "patient":
        p = db.query(PatientProfile).filter(PatientProfile.user_id==user.id).first(); q = q.filter(Appointment.patient_id==p.id)
    elif user.role == "doctor":
        d = db.query(DoctorProfile).filter(DoctorProfile.user_id==user.id).first(); q = q.filter(Appointment.doctor_id==d.id)
    else: raise HTTPException(403, "Use staff endpoints")
    return q.order_by(Appointment.created_at.desc()).all()

@app.post("/api/appointments/{appointment_id}/cancel")
def cancel(appointment_id: str, user: User = Depends(security.get_current_user), db: Session = Depends(get_db)):
    a = db.query(Appointment).get(appointment_id)
    if not a: raise HTTPException(404, "Not found")
    p = db.query(PatientProfile).filter(PatientProfile.user_id==user.id).first()
    if user.role == "patient" and a.patient_id != p.id: raise HTTPException(403, "Not your appointment")
    a.status = "cancelled"; a.slot.is_booked = False; db.commit()
    audit(db, user.id, "appointment.cancelled", "appointment:"+appointment_id)
    return {"ok": True}

@app.post("/api/appointments/{appointment_id}/status")
def set_appt_status(appointment_id: str, status: str, user: User = Depends(security.require_roles("doctor","staff","hospital_admin")), db: Session = Depends(get_db)):
    a = db.query(Appointment).get(appointment_id)
    if not a: raise HTTPException(404, "Not found")
    a.status = status; db.commit(); audit(db, user.id, "appointment.status_changed", "appointment:"+appointment_id, status)
    return {"ok": True}

@app.post("/api/records/encounter")
def create_encounter(data: schemas.EncounterIn, user: User = Depends(security.require_roles("doctor")), db: Session = Depends(get_db)):
    a = db.query(Appointment).get(data.appointment_id)
    if not a: raise HTTPException(404, "Appointment not found")
    d = db.query(DoctorProfile).filter(DoctorProfile.user_id==user.id).first()
    if a.doctor_id != d.id: raise HTTPException(403, "Not your appointment")
    e = EncounterRecord(appointment_id=a.id, patient_id=a.patient_id, doctor_id=d.id, symptoms=data.symptoms, findings=data.findings, diagnosis=data.diagnosis, treatment_plan=data.treatment_plan, follow_up=data.follow_up)
    db.add(e); a.status = "completed"; db.commit()
    audit(db, user.id, "encounter.created", "encounter:"+e.id)
    notify(db, a.patient.user_id, "record.added", "A new consultation record is available.", e.id)
    return {"id": e.id}

@app.post("/api/records/documents")
def upload_document(patient_id: str = Form(...), record_type: str = Form(...), file: UploadFile = File(...), user: User = Depends(security.get_current_user), db: Session = Depends(get_db)):
    content = file.file.read()
    if len(content) > 10*1024*1024: raise HTTPException(413, "File too large")
    h = hashlib.sha256(content).hexdigest()
    key = "private/"+patient_id+"/"+h[:16]+"_"+file.filename
    doc = MedicalDocument(patient_id=patient_id, uploaded_by=user.id, record_type=record_type, file_name=file.filename, file_hash=h, storage_key=key, verification_status="pending_verification")
    db.add(doc); db.commit()
    audit(db, user.id, "document.uploaded", "document:"+doc.id, h)
    return {"id": doc.id, "sha256": h, "verification_status": doc.verification_status, "note": "Demo stores metadata only; configure OBJECT_STORAGE_URL for private file storage."}

@app.get("/api/records/{patient_id}")
def records(patient_id: str, user: User = Depends(security.get_current_user), db: Session = Depends(get_db)):
    p = db.query(PatientProfile).filter(PatientProfile.user_id==user.id).first()
    if user.role == "patient" and (not p or p.id != patient_id): raise HTTPException(403, "Not authorized")
    encounters = db.query(EncounterRecord).filter(EncounterRecord.patient_id==patient_id).all()
    docs = db.query(MedicalDocument).filter(MedicalDocument.patient_id==patient_id).all()
    return {"encounters": [{"id":e.id,"diagnosis":e.diagnosis,"created_at":e.created_at} for e in encounters],
            "documents": [{"id":d.id,"type":d.record_type,"status":d.verification_status,"hash":d.file_hash[:12]} for d in docs]}

@app.post("/api/emergency")
def create_emergency(data: schemas.EmergencyCreate, user: User = Depends(security.get_current_user), db: Session = Depends(get_db)):
    p = db.query(PatientProfile).filter(PatientProfile.user_id==user.id).first()
    if not p: raise HTTPException(403, "Only patients can raise a personal emergency alert")
    e = EmergencyEvent(patient_id=p.id, created_by=user.id, description=data.description, urgency=data.urgency, status="alerting", notification_delivery="demo")
    db.add(e); db.commit()
    audit(db, user.id, "emergency.created", "emergency:"+e.id)
    notify(db, user.id, "emergency.created", "Emergency alert created. Demo mode: no live dispatch configured.", e.id)
    return {"id": e.id, "status": e.status, "delivery": "demo", "safety_notice": "For immediate help in India, call 112. MedShield is not a substitute for emergency services."}

@app.post("/api/emergency/{event_id}/acknowledge")
def acknowledge(event_id: str, user: User = Depends(security.require_roles("staff","hospital_admin","doctor")), db: Session = Depends(get_db)):
    e = db.query(EmergencyEvent).get(event_id)
    if not e: raise HTTPException(404, "Not found")
    e.status = "acknowledged"; e.acknowledged_at = dt.datetime.utcnow(); db.commit()
    audit(db, user.id, "emergency.acknowledged", "emergency:"+event_id)
    return {"ok": True, "status": e.status}

@app.post("/api/emergency/break-glass")
def break_glass(data: schemas.BreakGlassIn, user: User = Depends(security.require_roles("doctor")), db: Session = Depends(get_db)):
    e = db.query(EmergencyEvent).get(data.emergency_event_id)
    if not e: raise HTTPException(404, "Emergency event not found")
    g = RecordAccessGrant(patient_id=data.patient_id, clinician_id=user.id, emergency_event_id=e.id, reason=data.reason, scope=data.scope, expires_at=dt.datetime.utcnow()+dt.timedelta(minutes=min(data.minutes,60)), approved=True)
    db.add(g); db.commit()
    db.add(SecurityEvent(user_id=user.id, event_type="emergency_access", severity="high", detail="Break-glass access: "+data.reason, resource="patient:"+data.patient_id)); db.commit()
    audit(db, user.id, "emergency.break_glass", "grant:"+g.id, data.reason)
    return {"grant_id": g.id, "expires_at": g.expires_at, "scope": g.scope}

@app.post("/api/emergency/grants/{grant_id}/revoke")
def revoke(grant_id: str, user: User = Depends(security.require_roles("doctor","hospital_admin","security_admin")), db: Session = Depends(get_db)):
    g = db.query(RecordAccessGrant).get(grant_id)
    if not g: raise HTTPException(404, "Not found")
    g.revoked_at = dt.datetime.utcnow(); db.commit(); audit(db, user.id, "emergency.grant_revoked", "grant:"+grant_id)
    return {"ok": True}

@app.get("/api/security/events")
def security_events(user: User = Depends(security.require_roles("security_admin","hospital_admin")), db: Session = Depends(get_db)):
    return db.query(SecurityEvent).order_by(SecurityEvent.created_at.desc()).limit(100).all()

@app.get("/api/notifications")
def notifications(user: User = Depends(security.get_current_user), db: Session = Depends(get_db)):
    return db.query(Notification).filter(Notification.recipient_id==user.id).order_by(Notification.created_at.desc()).limit(50).all()

@app.post("/api/sales/inquiry")
def inquiry(data: schemas.InquiryIn, db: Session = Depends(get_db)):
    i = SalesInquiry(**data.dict()); db.add(i); db.commit()
    return {"ok": True, "id": i.id, "message": "Inquiry received."}
