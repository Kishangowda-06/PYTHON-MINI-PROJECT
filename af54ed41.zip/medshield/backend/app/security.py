import datetime as dt
from fastapi import Depends, HTTPException
from fastapi.security import OAuth2PasswordBearer
from jose import jwt, JWTError
from passlib.context import CryptContext
from sqlalchemy.orm import Session
from .config import settings
from .database import get_db
from .models import User
pwd = CryptContext(schemes=["bcrypt"], deprecated="auto")
oauth2 = OAuth2PasswordBearer(tokenUrl="/api/auth/login")
def hash_password(p): return pwd.hash(p)
def verify_password(p, h): return pwd.verify(p, h)
def create_token(sub, role, expires_minutes=None):
    exp = dt.datetime.utcnow() + dt.timedelta(minutes=expires_minutes or settings.access_token_expire_minutes)
    return jwt.encode({"sub": sub, "role": role, "exp": exp}, settings.jwt_secret, algorithm=settings.jwt_algorithm)
def get_current_user(token=Depends(oauth2), db: Session = Depends(get_db)):
    try:
        payload = jwt.decode(token, settings.jwt_secret, algorithms=[settings.jwt_algorithm])
    except JWTError:
        raise HTTPException(401, "Invalid or expired session")
    user = db.query(User).get(payload["sub"])
    if not user or not user.is_active: raise HTTPException(401, "Inactive user")
    return user
def require_roles(*roles):
    def checker(user: User = Depends(get_current_user)):
        if user.role not in roles: raise HTTPException(403, "Insufficient permissions")
        return user
    return checker
