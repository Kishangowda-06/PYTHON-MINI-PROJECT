from pydantic import BaseModel, EmailStr, Field
from typing import Optional
from datetime import datetime
class RegisterIn(BaseModel):
    email: EmailStr
    password: str = Field(min_length=8)
    full_name: str
    role: str = "patient"
    phone: Optional[str] = None
    date_of_birth: Optional[str] = None
class LoginIn(BaseModel):
    email: EmailStr
    password: str
class TokenOut(BaseModel):
    access_token: str
    token_type: str = "bearer"
    role: str
    full_name: str
class SlotOut(BaseModel):
    id: str; doctor_id: str; starts_at: datetime; ends_at: datetime; is_booked: bool
    class Config: from_attributes = True
class DoctorOut(BaseModel):
    id: str; full_name: str; specialization: Optional[str]; verification_status: str
    live_status: str; consultation_fee: float; status_updated_at: datetime
    class Config: from_attributes = True
class AppointmentCreate(BaseModel):
    slot_id: str
    reason: str = Field(min_length=3, max_length=500)
class AppointmentOut(BaseModel):
    id: str; status: str; reason: Optional[str]; created_at: datetime
    class Config: from_attributes = True
class EncounterIn(BaseModel):
    appointment_id: str
    symptoms: str; findings: str; diagnosis: str
    treatment_plan: Optional[str] = None; follow_up: Optional[str] = None
class EmergencyCreate(BaseModel):
    description: str = Field(min_length=5)
    urgency: str = "medium"
class BreakGlassIn(BaseModel):
    patient_id: str
    emergency_event_id: str
    reason: str
    scope: str = "limited"
    minutes: int = 30
class InquiryIn(BaseModel):
    name: str; email: EmailStr; organization: str
    org_type: str; message: str; consent: bool
