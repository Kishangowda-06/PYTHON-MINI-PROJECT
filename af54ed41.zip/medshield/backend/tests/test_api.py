from fastapi.testclient import TestClient
from app.main import app
client = TestClient(app)

def test_register_login_emergency():
    r = client.post("/api/auth/register", json={"email":"p1@test.com","password":"password123","full_name":"Test Patient","role":"patient"})
    assert r.status_code == 200
    token = r.json()["access_token"]
    r = client.post("/api/auth/login", json={"email":"p1@test.com","password":"password123"})
    assert r.status_code == 200
    r = client.post("/api/auth/register", json={"email":"p1@test.com","password":"password123","full_name":"Dup","role":"patient"})
    assert r.status_code == 409
    headers = {"Authorization": "Bearer "+token}
    r = client.post("/api/emergency", json={"description":"Chest pain and dizziness","urgency":"high"}, headers=headers)
    assert r.status_code == 200
    assert "112" in r.json()["safety_notice"]

def test_role_guard():
    r = client.post("/api/auth/register", json={"email":"p2@test.com","password":"password123","full_name":"P2","role":"patient"})
    token = r.json()["access_token"]
    r = client.get("/api/security/events", headers={"Authorization": "Bearer "+token})
    assert r.status_code == 403
